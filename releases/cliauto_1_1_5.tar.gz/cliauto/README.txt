CLI Auto

For documentation, see Help dashboard in app
